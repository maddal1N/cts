package cts.sirbu.madalin.g1086.Decorator.clase;

public interface IClip {
    void pause();

    void stop();

    void resume();

    void start();
}