package cts.sirbu.madalin.g1086.Composite.clase;

public interface IClip {
    void pause();

    void stop();

    void resume();

    void start();
}