package cts.sirbu.madalin.g1086.Composite.clase;

public abstract class ComponentaAbstracta2 {
    public abstract void printareElement();
    public abstract void adaugaNod(ComponentaAbstracta componentaAbstracta);
    public abstract void stergeNod(ComponentaAbstracta componentaAbstracta);

    public abstract ComponentaAbstracta getNod(int pozitie);
}
