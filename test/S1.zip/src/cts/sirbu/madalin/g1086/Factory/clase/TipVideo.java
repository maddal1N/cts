package cts.sirbu.madalin.g1086.Factory.clase;

public enum TipVideo {
    TUTORIAL,
    LIVE
}
