package cts.sirbu.madalin.g1086.Factory.clase;

public interface IClip {
    void pause();

    void stop();

    void resume();

    void start();
}